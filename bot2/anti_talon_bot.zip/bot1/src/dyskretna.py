# import
#  random
#
# dyskretna_tasks = { Q1: (),
#
#
#
# }
