TOKEN = '710251465:AAEYcnPpDnHD8ltuoXnpEVWEIrgUd1vNRxI'
leaderboard_path = "../datastorage/leaderboard.json"
courses_dict = {"discrete": 0, "history": 1}
storage_subject = ('', ['History', 'Math'], '')
OPINION = ""
gl_chosen_sub = "../src/datastorage/history.json"
DJEJORYKY = 200
SHCERBYNCHYKY = 200
