# Welcome to Floobits!

It looks like you're in an empty workspace. If you're using the web editor, you can 
click on the menu in the upper left to upload or create files.

If you're using a native editor, you might want to read our help docs at 
https://floobits.com/help/plugins/
